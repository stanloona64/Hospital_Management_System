<footer class="bg-blue text-center">
    <!-- Copyright -->
    <div class="text-center p-3 bg-info">
        <a class="text-white" href="../index.php">Hospital Information System -Beyza Önal</a>
    </div>
    <!-- Copyright -->
</footer>