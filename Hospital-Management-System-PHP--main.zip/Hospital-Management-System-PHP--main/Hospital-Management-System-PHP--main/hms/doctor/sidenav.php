<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

				<!--Yan menu-->
				<div class="list-group bg-info" style="height: 90vh;">
					<a href="index.php" class="list-group-item list-group-item-action
					bg-info text-center text-white">Dashboard</a>
					<a href="profile.php" class="list-group-item list-group-item-action
					bg-info text-center text-white">My Profile</a>
					<a href="patient.php" class="list-group-item list-group-item-action
					bg-info text-center text-white">Patient</a>
					<a href="appointment.php" class="list-group-item list-group-item-action
					bg-info text-center text-white">Appointment</a>
				</div>
				<!--son-->

</body>
</html>