# Hospital-Management-System-PHP-
Hospital management website made by php.
